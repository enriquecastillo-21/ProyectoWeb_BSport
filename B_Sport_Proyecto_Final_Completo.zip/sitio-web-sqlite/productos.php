<?php
include("admin/config/bd.php");
$consulta = $conexion->prepare("SELECT * FROM productos ORDER BY id DESC");
$consulta->execute();
$listaProductos = $consulta->fetchAll(PDO::FETCH_ASSOC);
include("templates/cabecera.php");
?>
<div class="col-12">
    <h1>Productos deportivos</h1>
    <div class="form-group"><label for="buscarProducto">Buscar producto</label><input type="text" id="buscarProducto" class="form-control" placeholder="Escribe el nombre de un producto"></div>
    <div class="row">
        <?php if (count($listaProductos) == 0) { ?>
            <p class="col-12">Todavía no hay productos registrados.</p>
        <?php } ?>
        <?php foreach ($listaProductos as $producto) { ?>
        <div class="col-md-4 mb-4 producto-card">
            <div class="card h-100">
                <img class="card-img-top" style="height:220px; object-fit:contain;"
                     src="img/<?php echo htmlspecialchars($producto['imagen']); ?>"
                     alt="<?php echo htmlspecialchars($producto['nombre']); ?>">
                <div class="card-body">
                    <h5 class="card-title"><?php echo htmlspecialchars($producto['nombre']); ?></h5>
                    <p class="card-text"><?php echo htmlspecialchars($producto['descripcion']); ?></p>
                    <p><strong>$<?php echo number_format((float)$producto['precio'], 2); ?></strong></p>
                </div>
            </div>
        </div>
        <?php } ?>
    </div>
</div>
<?php include("templates/pie.php"); ?>