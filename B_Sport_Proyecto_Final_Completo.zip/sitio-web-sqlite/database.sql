-- Base de datos de B Sport (SQLite)
CREATE TABLE IF NOT EXISTS usuarios (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    usuario TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS productos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL,
    descripcion TEXT,
    precio REAL DEFAULT 0,
    imagen TEXT NOT NULL
);

-- El administrador inicial se crea automáticamente desde admin/config/bd.php.
-- Usuario: admin
-- Contraseña: admin123
