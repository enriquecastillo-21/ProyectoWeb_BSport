# B Sport - Tienda de productos deportivos

## Descripción
B Sport es un sitio web sencillo para mostrar productos deportivos y administrar su catálogo. Los visitantes pueden consultar los productos y la sección Nosotros. Los usuarios pueden crear una cuenta e iniciar sesión para entrar al panel de administración, donde se pueden agregar, consultar, modificar y eliminar productos.

## Tecnologías utilizadas
- HTML5
- CSS y Bootstrap 4
- JavaScript
- PHP
- SQLite

## Requisitos
- XAMPP (Apache y PHP).
- Extensión PDO_SQLite habilitada en PHP.

## Instrucciones de ejecución
1. Descomprime la carpeta del proyecto dentro de `htdocs` de XAMPP.
2. Inicia Apache desde el panel de XAMPP.
3. Abre `http://localhost/sitio-web-sqlite/` en el navegador (usa el nombre real de la carpeta si lo cambiaste).
4. En la página principal puedes entrar a Productos o Nosotros.
5. Para administrar el catálogo, selecciona Iniciar sesión.
6. Puedes crear una cuenta desde el enlace Crear cuenta.
7. También existe un administrador inicial: usuario `admin`, contraseña `admin123`.

## Base de datos
La base de datos SQLite se crea automáticamente en `admin/config/sitio.sqlite` al abrir el sitio. Las tablas `usuarios` y `productos` se crean si todavía no existen.

## Funciones principales
- Registro e inicio/cierre de sesión.
- Catálogo dinámico de productos.
- Búsqueda de productos con JavaScript.
- CRUD de productos: crear, leer, actualizar y eliminar.
- Validación de formularios con JavaScript y validación del navegador.

## Repositorio
Sube esta carpeta a un repositorio de GitHub y realiza commits representativos durante el desarrollo.
