// JavaScript básico para B Sport
document.addEventListener("DOMContentLoaded", function () {
    // Validación de formularios
    var formularios = document.querySelectorAll("form[data-validar]");

    formularios.forEach(function (formulario) {
        formulario.addEventListener("submit", function (evento) {
            var password = formulario.querySelector('[name="contrasenia"]');
            var confirmar = formulario.querySelector('[name="confirmar"]');
            if (password && confirmar && password.value !== confirmar.value) {
                evento.preventDefault();
                confirmar.setCustomValidity("Las contraseñas no coinciden.");
                formulario.classList.add("was-validated");
                mostrarMensaje(formulario, "Las contraseñas no coinciden.", "danger");
                return;
            }
            if (confirmar) {
                confirmar.setCustomValidity("");
            }
            if (!formulario.checkValidity()) {
                evento.preventDefault();
                evento.stopPropagation();
                formulario.classList.add("was-validated");
                mostrarMensaje(formulario, "Revisa los campos. Todos los datos obligatorios deben estar completos.", "danger");
            } else if (formulario.dataset.confirmar === "true") {
                if (!confirm("¿Deseas guardar estos cambios?")) {
                    evento.preventDefault();
                }
            }
        });
    });

    // Búsqueda dinámica de productos: modifica el DOM sin recargar la página.
    var buscador = document.getElementById("buscarProducto");
    if (buscador) {
        buscador.addEventListener("keyup", function () {
            var texto = buscador.value.toLowerCase();
            var tarjetas = document.querySelectorAll(".producto-card");
            tarjetas.forEach(function (tarjeta) {
                var nombre = tarjeta.textContent.toLowerCase();
                tarjeta.style.display = nombre.includes(texto) ? "" : "none";
            });
        });
    }

    // Mensaje de bienvenida en el panel de administración.
    var saludo = document.getElementById("saludoAdmin");
    if (saludo) {
        saludo.addEventListener("click", function () {
            saludo.textContent = "¡Gracias por administrar B Sport!";
        });
    }
});

function mostrarMensaje(formulario, texto, tipo) {
    var mensaje = formulario.querySelector(".mensaje-validacion");
    if (!mensaje) {
        mensaje = document.createElement("div");
        mensaje.className = "alert mensaje-validacion";
        formulario.prepend(mensaje);
    }
    mensaje.className = "alert alert-" + tipo + " mensaje-validacion";
    mensaje.textContent = texto;
}
