<?php include("templates/cabecera.php"); ?>
<div class="col-12 text-center jumbotron">
    <h1 class="display-4">Bienvenidos a B Sport</h1>
    <p class="lead">Encuentra productos deportivos para tus actividades favoritas.</p>
    <hr>
    <p>Calidad, variedad y buenos precios para seguir en movimiento.</p>
    <a class="btn btn-primary btn-lg" href="productos.php">Ver productos</a>
</div>
<?php include("templates/pie.php"); ?>