<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>B Sport - Tienda deportiva</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<link rel="stylesheet" href="css/estilos.css">
</head>
<body>
<header>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <a class="navbar-brand" href="index.php">B Sport</a>
    <div class="navbar-nav">
        <a class="nav-item nav-link" href="index.php">Inicio</a>
        <a class="nav-item nav-link" href="productos.php">Productos</a>
        <a class="nav-item nav-link" href="nosotros.php">Nosotros</a>
        <a class="nav-item nav-link" href="admin/index.php">Iniciar sesión</a>
        <a class="nav-item nav-link" href="admin/registro.php">Crear cuenta</a>
    </div>
</nav>
</header>
<main class="container">
    <br>
    <div class="row">
