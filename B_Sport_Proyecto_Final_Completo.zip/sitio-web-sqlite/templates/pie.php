</main>
<footer class="bg-light text-center p-3 mt-4">
    <p class="mb-0">B Sport - Tienda de productos deportivos</p>
</footer>
<script src="js/app.js"></script>
</body>
</html>
