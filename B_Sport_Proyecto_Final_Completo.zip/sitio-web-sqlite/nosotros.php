<?php include("templates/cabecera.php"); ?>
<div class="col-12 jumbotron">
    <h1>Nosotros</h1>
    <p class="lead">B Sport es una tienda dedicada a la venta de productos deportivos de diferentes marcas y disciplinas.</p>
    <p>Buscamos ofrecer artículos de calidad y precios accesibles para niños, jóvenes y adultos.</p>
</div>
<?php include("templates/pie.php"); ?>