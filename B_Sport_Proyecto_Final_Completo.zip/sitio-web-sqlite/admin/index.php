<?php
session_start();
include("config/bd.php");
$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $usuario = trim($_POST["usuario"] ?? "");
    $contrasenia = $_POST["contrasenia"] ?? "";

    $consulta = $conexion->prepare("SELECT * FROM usuarios WHERE usuario = ?");
    $consulta->execute([$usuario]);
    $registro = $consulta->fetch(PDO::FETCH_ASSOC);

    if ($registro && (password_verify($contrasenia, $registro["password"]) || $contrasenia === $registro["password"])) {
        // Actualiza contraseñas antiguas que estuvieran guardadas sin cifrar.
        if (!password_get_info($registro["password"])["algo"]) {
            $nuevoPassword = password_hash($contrasenia, PASSWORD_DEFAULT);
            $actualizar = $conexion->prepare("UPDATE usuarios SET password = ? WHERE id = ?");
            $actualizar->execute([$nuevoPassword, $registro["id"]]);
        }
        $_SESSION["usuario"] = "ok";
        $_SESSION["nombreUsuario"] = $registro["usuario"];
        header("Location: inicio.php");
        exit;
    } else {
        $mensaje = "El usuario o la contraseña son incorrectos.";
    }
}
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Iniciar sesión - B Sport</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body class="bg-light">
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-5 mt-5">
            <div class="card">
                <div class="card-header">Iniciar sesión en B Sport</div>
                <div class="card-body">
                    <?php if ($mensaje != "") { ?><div class="alert alert-danger"><?php echo $mensaje; ?></div><?php } ?>
                    <form method="POST" data-validar>
                        <div class="form-group">
                            <label>Usuario</label>
                            <input type="text" name="usuario" class="form-control" minlength="3" required>
                        </div>
                        <div class="form-group">
                            <label>Contraseña</label>
                            <input type="password" name="contrasenia" class="form-control" minlength="4" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Entrar</button>
                        <a href="registro.php" class="btn btn-link">Crear cuenta</a>
                        <a href="../index.php" class="btn btn-link">Volver</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>