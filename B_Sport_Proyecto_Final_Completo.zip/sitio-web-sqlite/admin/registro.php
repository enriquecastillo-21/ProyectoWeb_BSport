<?php
include("config/bd.php");
$mensaje = "";
$tipoMensaje = "danger";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $usuario = trim($_POST["usuario"] ?? "");
    $password = $_POST["contrasenia"] ?? "";
    $confirmar = $_POST["confirmar"] ?? "";

    if ($usuario == "" || $password == "") {
        $mensaje = "Completa todos los campos.";
    } elseif (strlen($password) < 4) {
        $mensaje = "La contraseña debe tener al menos 4 caracteres.";
    } elseif ($password != $confirmar) {
        $mensaje = "Las contraseñas no coinciden.";
    } else {
        try {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $insertar = $conexion->prepare("INSERT INTO usuarios (usuario, password) VALUES (?, ?)");
            $insertar->execute([$usuario, $hash]);
            $mensaje = "Tu cuenta se creó correctamente. Ya puedes iniciar sesión.";
            $tipoMensaje = "success";
        } catch (PDOException $error) {
            $mensaje = "Ese nombre de usuario ya está registrado.";
        }
    }
}
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Crear cuenta - B Sport</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body class="bg-light">
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-5 mt-5">
            <div class="card">
                <div class="card-header">Crear cuenta</div>
                <div class="card-body">
                    <?php if ($mensaje != "") { ?><div class="alert alert-<?php echo $tipoMensaje; ?>"><?php echo htmlspecialchars($mensaje); ?></div><?php } ?>
                    <form method="POST" data-validar>
                        <div class="form-group">
                            <label>Nombre de usuario</label>
                            <input type="text" name="usuario" class="form-control" minlength="3" required>
                        </div>
                        <div class="form-group">
                            <label>Contraseña</label>
                            <input type="password" name="contrasenia" class="form-control" minlength="4" required>
                        </div>
                        <div class="form-group">
                            <label>Confirmar contraseña</label>
                            <input type="password" name="confirmar" class="form-control" minlength="4" required>
                        </div>
                        <button type="submit" class="btn btn-success">Registrarme</button>
                        <a href="index.php" class="btn btn-link">Iniciar sesión</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>