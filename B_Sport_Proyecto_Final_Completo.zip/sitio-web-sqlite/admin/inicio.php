<?php include("template/cabecera.php"); ?>
<div class="col-12">
    <div class="jumbotron">
        <h1 id="saludoAdmin" title="Haz clic para cambiar el mensaje">Bienvenido <?php echo htmlspecialchars($nombreUsuario); ?></h1>
        <p class="lead">Desde aquí puedes administrar los productos deportivos de B Sport.</p>
        <a class="btn btn-primary btn-lg" href="seccion/productos.php">Administrar productos</a>
    </div>
</div>
<?php include("template/pie.php"); ?>