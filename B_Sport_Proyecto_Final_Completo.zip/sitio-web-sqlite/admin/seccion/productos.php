<?php
include("../template/cabecera.php");
include("../config/bd.php");

$id = $_POST["id"] ?? "";
$nombre = trim($_POST["nombre"] ?? "");
$descripcion = trim($_POST["descripcion"] ?? "");
$precio = $_POST["precio"] ?? "0";
$accion = $_POST["accion"] ?? "";
$imagenActual = "";

if ($accion == "Seleccionar") {
    $consulta = $conexion->prepare("SELECT * FROM productos WHERE id = ?");
    $consulta->execute([$id]);
    $producto = $consulta->fetch(PDO::FETCH_ASSOC);
    if ($producto) {
        $nombre = $producto["nombre"];
        $descripcion = $producto["descripcion"];
        $precio = $producto["precio"];
        $imagenActual = $producto["imagen"];
    }
}

if ($accion == "Agregar" || $accion == "Modificar") {
    $archivo = $_FILES["imagen"]["name"] ?? "";
    $nombreImagen = "";

    if ($archivo != "" && $_FILES["imagen"]["error"] == 0) {
        $extension = strtolower(pathinfo($archivo, PATHINFO_EXTENSION));
        if (in_array($extension, ["jpg", "jpeg", "png", "gif", "webp"])) {
            $nombreImagen = time() . "_" . basename($archivo);
            move_uploaded_file($_FILES["imagen"]["tmp_name"], "../../img/" . $nombreImagen);
        }
    }

    if ($accion == "Agregar") {
        if ($nombreImagen == "") {
            $nombreImagen = "producto.svg";
        }
        $insertar = $conexion->prepare("INSERT INTO productos (nombre, descripcion, precio, imagen) VALUES (?, ?, ?, ?)");
        $insertar->execute([$nombre, $descripcion, $precio, $nombreImagen]);
    } else {
        if ($nombreImagen != "") {
            $actual = $conexion->prepare("SELECT imagen FROM productos WHERE id = ?");
            $actual->execute([$id]);
            $anterior = $actual->fetchColumn();
            $actualizar = $conexion->prepare("UPDATE productos SET nombre=?, descripcion=?, precio=?, imagen=? WHERE id=?");
            $actualizar->execute([$nombre, $descripcion, $precio, $nombreImagen, $id]);
            if ($anterior && $anterior != "producto.svg" && file_exists("../../img/" . $anterior)) {
                unlink("../../img/" . $anterior);
            }
        } else {
            $actualizar = $conexion->prepare("UPDATE productos SET nombre=?, descripcion=?, precio=? WHERE id=?");
            $actualizar->execute([$nombre, $descripcion, $precio, $id]);
        }
    }
    header("Location: productos.php");
    exit;
}

if ($accion == "Borrar") {
    $consulta = $conexion->prepare("SELECT imagen FROM productos WHERE id = ?");
    $consulta->execute([$id]);
    $imagen = $consulta->fetchColumn();
    $borrar = $conexion->prepare("DELETE FROM productos WHERE id = ?");
    $borrar->execute([$id]);
    if ($imagen && $imagen != "producto.svg" && file_exists("../../img/" . $imagen)) {
        unlink("../../img/" . $imagen);
    }
    header("Location: productos.php");
    exit;
}

$consulta = $conexion->prepare("SELECT * FROM productos ORDER BY id DESC");
$consulta->execute();
$listaProductos = $consulta->fetchAll(PDO::FETCH_ASSOC);
?>
<div class="col-md-4">
    <div class="card">
        <div class="card-header">Datos del producto</div>
        <div class="card-body">
            <form method="POST" enctype="multipart/form-data" data-validar>
                <input type="hidden" name="id" value="<?php echo htmlspecialchars($id); ?>">
                <div class="form-group">
                    <label>Nombre</label>
                    <input type="text" name="nombre" class="form-control" minlength="2" value="<?php echo htmlspecialchars($nombre); ?>" required>
                </div>
                <div class="form-group">
                    <label>Descripción</label>
                    <textarea name="descripcion" class="form-control"><?php echo htmlspecialchars($descripcion); ?></textarea>
                </div>
                <div class="form-group">
                    <label>Precio</label>
                    <input type="number" name="precio" min="0" step="0.01" class="form-control" value="<?php echo htmlspecialchars($precio); ?>" required>
                </div>
                <div class="form-group">
                    <label>Imagen</label>
                    <?php if ($imagenActual != "") { ?>
                        <img src="../../img/<?php echo htmlspecialchars($imagenActual); ?>" width="70" class="d-block mb-2" alt="">
                    <?php } ?>
                    <input type="file" name="imagen" class="form-control-file" accept=".jpg,.jpeg,.png,.gif,.webp">
                </div>
                <?php if ($id == "") { ?>
                    <button type="submit" name="accion" value="Agregar" class="btn btn-success">Agregar</button>
                <?php } else { ?>
                    <button type="submit" name="accion" value="Modificar" class="btn btn-warning">Modificar</button>
                    <a href="productos.php" class="btn btn-secondary">Cancelar</a>
                <?php } ?>
            </form>
        </div>
    </div>
</div>
<div class="col-md-8">
    <h4>Productos registrados</h4>
    <table class="table table-bordered table-sm">
        <thead>
            <tr><th>ID</th><th>Nombre</th><th>Precio</th><th>Imagen</th><th>Acciones</th></tr>
        </thead>
        <tbody>
        <?php foreach ($listaProductos as $producto) { ?>
            <tr>
                <td><?php echo $producto["id"]; ?></td>
                <td><?php echo htmlspecialchars($producto["nombre"]); ?></td>
                <td>$<?php echo number_format((float)$producto["precio"], 2); ?></td>
                <td><img src="../../img/<?php echo htmlspecialchars($producto["imagen"]); ?>" width="55" alt=""></td>
                <td>
                    <form method="POST" class="d-inline">
                        <input type="hidden" name="id" value="<?php echo $producto["id"]; ?>">
                        <button type="submit" name="accion" value="Seleccionar" class="btn btn-primary btn-sm">Editar</button>
                        <button type="submit" name="accion" value="Borrar" class="btn btn-danger btn-sm" onclick="return confirm('¿Eliminar este producto?')">Eliminar</button>
                    </form>
                </td>
            </tr>
        <?php } ?>
        </tbody>
    </table>
</div>
<?php include("../template/pie.php"); ?>