<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION["usuario"]) || $_SESSION["usuario"] != "ok") {
    header("Location: ../index.php");
    exit;
}
$nombreUsuario = $_SESSION["nombreUsuario"];
$ruta = str_replace("\\", "/", dirname($_SERVER["SCRIPT_NAME"]));
$base = preg_replace("~/admin(?:/seccion)?$~", "", $ruta);
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Administración - B Sport</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo $base; ?>/css/estilos.css">
</head>
<body>
<header>
<nav class="navbar navbar-expand navbar-light bg-light">
    <a class="navbar-brand" href="<?php echo $base; ?>/admin/inicio.php">B Sport</a>
    <div class="navbar-nav">
        <a class="nav-item nav-link" href="<?php echo $base; ?>/admin/inicio.php">Inicio</a>
        <a class="nav-item nav-link" href="<?php echo $base; ?>/admin/seccion/productos.php">Productos</a>
        <a class="nav-item nav-link" href="<?php echo $base; ?>/admin/seccion/cerrar.php">Cerrar sesión</a>
        <a class="nav-item nav-link" href="<?php echo $base; ?>/index.php">Ver tienda</a>
    </div>
</nav>
</header>
<main class="container">
    <br>
    <div class="row">
