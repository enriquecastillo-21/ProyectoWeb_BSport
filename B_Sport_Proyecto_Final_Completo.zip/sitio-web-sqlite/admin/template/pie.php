</main>
<footer class="bg-light text-center p-3 mt-4">
    <p class="mb-0">Panel de administración - B Sport</p>
</footer>
<script src="<?php echo $base; ?>/js/app.js"></script>
</body>
</html>
