<?php
$archivoBD = __DIR__ . "/sitio.sqlite";

try {
    $conexion = new PDO("sqlite:" . $archivoBD);
    $conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $conexion->exec("CREATE TABLE IF NOT EXISTS usuarios (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        usuario TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL
    )");

    $conexion->exec("CREATE TABLE IF NOT EXISTS productos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nombre TEXT NOT NULL,
        descripcion TEXT,
        precio REAL DEFAULT 0,
        imagen TEXT NOT NULL
    )");

    // Usuario administrador inicial. La contraseña se guarda cifrada.
    $consulta = $conexion->prepare("SELECT id FROM usuarios WHERE usuario = ?");
    $consulta->execute(["admin"]);
    if (!$consulta->fetch()) {
        $password = password_hash("admin123", PASSWORD_DEFAULT);
        $insertar = $conexion->prepare("INSERT INTO usuarios (usuario, password) VALUES (?, ?)");
        $insertar->execute(["admin", $password]);
    }
} catch (PDOException $error) {
    die("Error al conectar con la base de datos: " . $error->getMessage());
}
?>