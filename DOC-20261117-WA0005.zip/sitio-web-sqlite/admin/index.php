<?php
/*
--- CAMBIOS REALIZADOS PARA SQLITE ---
1. Se cambió fetch(PDO::FETCH_LAZY) por fetch(PDO::FETCH_ASSOC) o fetch() estándar, ya que en algunas versiones del driver PDO SQLite de PHP, FETCH_LAZY puede presentar comportamientos inconsistentes con los cursores de SQLite al autenticar. La lógica se mantiene intacta.

--- CÓDIGO ORIGINAL REEMPLAZADO ---
    $sentenciaSQL = $conexion->prepare("SELECT * FROM usuarios WHERE usuario=:usuario AND password=:password");
    $sentenciaSQL->bindParam(':usuario', $usuario);
    $sentenciaSQL->bindParam(':password', $contrasenia);
    $sentenciaSQL->execute();
    $registro = $sentenciaSQL->fetch(PDO::FETCH_LAZY);
----------------------------------
*/

session_start();
include("config/bd.php");

if ($_POST) {
    $usuario = (isset($_POST['usuario'])) ? $_POST['usuario'] : "";
    $contrasenia = (isset($_POST['contrasenia'])) ? $_POST['contrasenia'] : "";

    $sentenciaSQL = $conexion->prepare("SELECT * FROM usuarios WHERE usuario=:usuario AND password=:password");
    $sentenciaSQL->bindParam(':usuario', $usuario);
    $sentenciaSQL->bindParam(':password', $contrasenia);
    $sentenciaSQL->execute();
    $registro = $sentenciaSQL->fetch(PDO::FETCH_ASSOC);

    if ($registro) {
        $_SESSION['usuario'] = "ok";
        $_SESSION['nombreUsuario'] = $registro['usuario'];
        header('Location:inicio.php');
    } else {
        $mensaje = "Error: El usuario o contraseña son incorrectos";
    }
}
?>
<!doctype html>
<html lang="es">
<head>
    <title>Administrador del sitio web</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" crossorigin="anonymous">
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-4"></div>
            <div class="col-md-4">
                <br/><br/><br/>
                <div class="card">
                    <div class="card-header">
                        Login
                    </div>
                    <div class="card-body">
                        <?php if (isset($mensaje)) { ?>
                            <div class="alert alert-danger" role="alert">
                                <?php echo $mensaje; ?>
                            </div>
                        <?php } ?>
                        <form method="POST">
                            <div class="form-group">
                                <label>Usuario</label>
                                <input type="text" class="form-control" name="usuario" placeholder="Escribe tu usuario" required>
                            </div>
                            <div class="form-group">
                                <label>Contraseña:</label>
                                <input type="password" class="form-control" name="contrasenia" placeholder="Escribe tu contraseña" required>
                            </div>
                            <button type="submit" class="btn btn-primary">Entrar al administrador</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
