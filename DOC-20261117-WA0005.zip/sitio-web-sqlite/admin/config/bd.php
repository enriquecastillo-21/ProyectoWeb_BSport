<?php
/* 
--- CAMBIOS REALIZADOS PARA SQLITE ---
1. Se reemplazó la conexión MySQL por PDO SQLite apuntando a un archivo local 'sitio.sqlite'.
2. Se eliminaron las variables de host, usuario y contraseña de MySQL ($host, $usuario, $contrasenia).
3. Se añadió la creación automática de las tablas e inserción del usuario administrador inicial si el archivo de base de datos no existe previamente, facilitando su ejecución directa en VS Code.

--- CÓDIGO ORIGINAL REEMPLAZADO ---
$host = "localhost";
$bd = "sitio";
$usuario = "root";
$contrasenia = "";

try {
    $conexion = new PDO("mysql:host=$host;dbname=$bd", $usuario, $contrasenia);
    $conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (Exception $ex) {
    echo $ex->getMessage();
}
----------------------------------
*/

$archivoBD = __DIR__ . '/sitio.sqlite';
$crearTabla = !file_exists($archivoBD);

try {
    $conexion = new PDO("sqlite:" . $archivoBD);
    $conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if ($crearTabla) {
        $conexion->exec("CREATE TABLE IF NOT EXISTS libros (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            imagen TEXT NOT NULL
        );");

        $conexion->exec("CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            usuario TEXT NOT NULL,
            password TEXT NOT NULL
        );");

        $conexion->exec("INSERT INTO usuarios (usuario, password) VALUES ('develoteca', 'sistema');");
    }
} catch (Exception $ex) {
    echo $ex->getMessage();
}
?>
