<?php
/*
--- CAMBIOS REALIZADOS PARA SQLITE ---
1. Se ajustó la ruta dinámica de la URL base calculándola a partir de $_SERVER['SCRIPT_NAME'] en lugar de $_SERVER['HTTP_HOST'] estricto para que funcione perfectamente con servidores de desarrollo locales integrados en VS Code (como PHP Built-in Server: php -S localhost:8000).

--- CÓDIGO ORIGINAL REEMPLAZADO ---
    <?php $url = "http://" . $_SERVER['HTTP_HOST'] . "/sitio-web-php"; ?>
----------------------------------
*/

session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location:../index.php");
} else {
    if ($_SESSION['usuario'] == "ok") {
        $nombreUsuario = $_SESSION["nombreUsuario"];
    }
}
?>
<!doctype html>
<html lang="es">
<head>
    <title>Administrador</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" crossorigin="anonymous">
</head>
<body>
    <?php 
        $dir_proyecto = rtrim(dirname(dirname(dirname($_SERVER['SCRIPT_NAME']))), '/\');
        $url = "http://" . $_SERVER['HTTP_HOST'] . $dir_proyecto; 
    ?>

    <nav class="navbar navbar-expand navbar-light bg-light">
        <div class="nav navbar-nav">
            <a class="nav-item nav-link active" href="#">Administrador del sitio web <span class="sr-only">(current)</span></a>
            <a class="nav-item nav-link" href="<?php echo $url; ?>/admin/inicio.php">Inicio</a>
            <a class="nav-item nav-link" href="<?php echo $url; ?>/admin/seccion/productos.php">Libros</a>
            <a class="nav-item nav-link" href="<?php echo $url; ?>/admin/seccion/cerrar.php">Cerrar</a>
            <a class="nav-item nav-link" href="<?php echo $url; ?>">Ver sitio web</a>
        </div>
    </nav>

    <div class="container">
        <br/>
        <div class="row">
