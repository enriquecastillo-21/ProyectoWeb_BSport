-- NOTA: SQLite no utiliza un servidor de base de datos separado ni el comando CREATE DATABASE.
-- En su lugar, se crea un archivo físico local (por ejemplo, 'sitio.sqlite') manejado por PDO.
-- A continuación se muestra la estructura SQL equivalente para crear las tablas en SQLite:

/*
CREATE TABLE IF NOT EXISTS libros (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    TEXT NOT NULL, -- o simplemente TEXT
    nombre TEXT NOT NULL,
    imagen TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS usuarios (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    usuario TEXT NOT NULL,
    password TEXT NOT NULL
);

INSERT INTO usuarios (usuario, password) VALUES ('develoteca', 'sistema');
*/
