<?php include("templates/cabecera.php"); ?>

<div class="jumbotron text-center col-12">
    <h1 class="display-3">Bienvenidos al sitio de Libros</h1>
    <p class="lead">Consulta libros de programación</p>
    <hr class="my-2">
    <img width="400" src="img/banner.jpg" class="img-thumbnail rounded mx-auto d-block" alt="Banner" />
    <p>Más información</p>
    <p class="lead">
        <a class="btn btn-primary btn-lg" href="productos.php" role="button">Ver almacén de libros</a>
    </p>
</div>

<?php include("templates/pie.php"); ?>
