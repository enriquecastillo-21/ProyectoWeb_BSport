<?php include("templates/cabecera.php"); ?>

<div class="jumbotron col-12">
    <h1 class="display-3">Nosotros</h1>
    <p class="lead">Hola que tal somos un grupo de personas que se dedican al desarrollo web.</p>
    <hr class="my-2">
</div>

<?php include("templates/pie.php"); ?>
